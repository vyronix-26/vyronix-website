const express = require('express');
const router = express.Router();
const chatbotController = require('./chatbot.controller');

// مسار الشات بوت
router.post('/message', chatbotController.handleMessage);

module.exports = router;