const { GoogleGenAI } = require("@google/genai");

const pool = require("../../config/db");

const getGeminiClient = () => {
  if (!process.env.GEMINI_API_KEY) {
    throw new Error("GEMINI_API_KEY is not configured");
  }

  return new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
};

exports.handleMessage = async (req, res) => {
  try {
    const { message, userId } = req.body;
    const cleanMessage = typeof message === "string" ? message.trim() : "";
let cleanUserId = null;

if (userId) {
  const [user] = await pool.query(
    "SELECT id FROM users WHERE id = ?",
    [userId]
  );

  if (user.length > 0) {
    cleanUserId = userId;
  }
}
    if (!cleanMessage) {
      return res.status(400).json({
        success: false,
        message: "Message is required",
      });
    }

    await pool.query(
      "INSERT INTO chatbot_messages (user_id, sender, message) VALUES (?, ?, ?)",
      [cleanUserId, "user", cleanMessage]
    );

    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: cleanMessage,
      config: {
        systemInstruction:
          "You are the Vyronix website assistant. Answer clearly, briefly, and in the same language as the user. Help users understand services, projects, and how to request a project.",
      },
    });

    const botResponse =
      typeof response.text === "string" && response.text.trim()
        ? response.text.trim()
        : "I could not process your request right now.";

    await pool.query(
      "INSERT INTO chatbot_messages (user_id, sender, message) VALUES (?, ?, ?)",
      [cleanUserId, "bot", botResponse]
    );

    return res.status(200).json({
      success: true,
      data: {
        sender: "bot",
        message: botResponse,
      },
    });
  } catch (error) {
    console.error("Chatbot Error:", error.message);

    return res.status(500).json({
      success: false,
      message: "Chatbot service is currently unavailable.",
    });
  }
};